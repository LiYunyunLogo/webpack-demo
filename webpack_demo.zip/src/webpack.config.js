const  path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const {CleanWebpackPlugin} = require('clean-webpack-plugin');
const webpack = require('webpack');

module.exports=(env, argv) => {
    return{
    entry:{
        app: './src/index.js'
        // print: './src/print.js'
    },
    mode:argv.mode,
    output:{
        filename: '[name].bundle.js',
        path: path.resolve(__dirname, argv.mode == 'production' ? 'dist': 'test'),
        publicPath: './'
    },
    devServer: {
        port:8080,
        contentBase: './dist',
        hot: true
        },
    devtool: 'inline-source-map',
    plugins:[
        // 默认生成 index.html 文件
        new HtmlWebpackPlugin({
            title:'Output Management'
        }),
        // 在每次构建前清理 /dist ，然后生成新的dist文件夹
        new CleanWebpackPlugin(),
        // 以便更容易查看要修补(patch)的依赖
        new webpack.NamedModulesPlugin(),
        //热更新插件
        new webpack.HotModuleReplacementPlugin()
    ],    
    module:{
        rules:[
            {
                test: /\.css$/,
                use:[
                    'style-loader',
                    "css-loader"
                ],
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                use:[
                    'file-loader'
                ],
            },
        ]
    }
}
}