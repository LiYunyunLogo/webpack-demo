export default function printMe() {
    console.log('Updating print.js...')
  }